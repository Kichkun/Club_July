[SPIFFS] data   : /ESP8266/Forum/Display_AP-JS/data
[SPIFFS] size   : 3052
[SPIFFS] page   : 256
[SPIFFS] block  : 8192
/raphael-2.1.4.min.js.gz
/counter.html
/justgage.js.gz
[SPIFFS] upload : /tmp/build9440e7a7911169d6042bfb4fcfa06d9c.spiffs/Display_AP-JS.spiffs.bin
[SPIFFS] address: 0x100000
[SPIFFS] reset  : nodemcu
[SPIFFS] port   : /dev/ttyUSB0
[SPIFFS] speed  : 115200

Uploading 3125248 bytes from to flash at 0x00100000
.............................................................................................


Sample serial console session during active page refresh on tablet:
Configuring access point...AP IP address: 192.168.4.1
HTTP server started
handleFileRead: /
PathFile: /counter.html.gz
handleFileRead: /
PathFile: /counter.html.gz
handleFileRead: /raphael-2.1.4.min.js
PathFile: /raphael-2.1.4.min.js.gz
handleFileRead: /justgage.js
PathFile: /justgage.js.gz
handleFileRead: /
PathFile: /counter.html.gz
handleFileRead: /raphael-2.1.4.min.js
PathFile: /raphael-2.1.4.min.js.gz
handleFileRead: /justgage.js
PathFile: /justgage.js.gz

